package com.capgemini.pms.exception;

public class ProductException {


	private static final long serialVersionUID = 1L;
	
	public String msg;
	public ProductException(String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return msg;
	}
}
