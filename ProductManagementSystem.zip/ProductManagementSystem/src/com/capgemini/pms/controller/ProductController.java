package com.capgemini.pms.controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.capgemini.pms.entity.Product;
import com.capgemini.pms.service.IProductservice;

@Controller
public class ProductController {


@Autowired
IProductservice service;

@RequestMapping("/home")
public String displayPage(Model model)
{
String view = "displayproducts";
ArrayList<Product> list = service.getAllProducts();
model.addAttribute("productstorage", list);
return view;

}

@RequestMapping("/purchasing")
public String purchasingPage(Model model) {
	String view = "";
	String productName = service.findProductName();
	model.addAttribute("productName", productName);
	view = "PurchasingConfirmation";
	return view;
	
}
}
