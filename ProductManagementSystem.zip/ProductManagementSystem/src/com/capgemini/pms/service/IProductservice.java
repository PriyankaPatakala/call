package com.capgemini.pms.service;

import java.util.ArrayList;

import com.capgemini.pms.entity.Product;

public interface IProductservice {
	
public ArrayList<Product> getAllProducts();

	public String findProductName();
	
	
}
