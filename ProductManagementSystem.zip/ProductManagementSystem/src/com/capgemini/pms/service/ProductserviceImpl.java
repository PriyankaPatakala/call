package com.capgemini.pms.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.pms.dao.IProductdao;
import com.capgemini.pms.entity.Product;


@Service
public class ProductserviceImpl implements IProductservice {
	
	@Autowired
	IProductdao productdao;
	
	

	@Override
	public ArrayList<Product> getAllProducts() {
	
		return productdao.getAllProducts();
		
	}

	@Override
	public String findProductName() {
		
		return productdao.findProductName();
		
	}

}
