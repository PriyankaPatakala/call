package com.capgemini.pms.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.pms.entity.Product;
import com.capgemini.pms.service.IProductservice;


@Repository
public class ProductdaoImpl implements IProductservice {
	
    @PersistenceContext
	EntityManager em;
	
	@Override
	public ArrayList<Product> getAllProducts() {
		ArrayList<Product> list= new ArrayList<>();
		Query query= em.createNamedQuery("getallproducts");
		List<Product> productstore= query.getResultList();
		return (ArrayList<Product>) productstore;
		
	}

	@Override
	public String findProductName() {

			//String jpql ="Select productname from Productstore product where id = 1";
			Query query =em.createNamedQuery("findProductName");
			String productName = (String) query.getSingleResult();
			return productName;
		//return (String) query.getSingleResult();
	}

}
