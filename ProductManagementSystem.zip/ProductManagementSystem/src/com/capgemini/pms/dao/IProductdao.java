package com.capgemini.pms.dao;

import java.util.ArrayList;

import com.capgemini.pms.entity.Product;

public interface IProductdao {

	ArrayList<Product> getAllProducts();

	String findProductName();

	
	
}
