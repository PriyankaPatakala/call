package com.capg.gear.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.gear.dao.IGearDao;
import com.capg.gear.model.GearForm;

@Service
public class GearServiceImpl implements IGearService {
	@Autowired
	IGearDao dao;

	@Override
	public GearForm findqueryID(Integer queryID) {
		return dao.findqueryID(queryID);
	}



	@Override
	public boolean textarea(Integer queryID, String textarea) {
		// TODO Auto-generated method stub
		return dao.textarea(queryID,textarea);
	}

}
