package com.capg.gear.service;

import com.capg.gear.model.GearForm;

public interface IGearService {
GearForm findqueryID(Integer queryID);



boolean textarea(Integer queryID, String textarea);
}
