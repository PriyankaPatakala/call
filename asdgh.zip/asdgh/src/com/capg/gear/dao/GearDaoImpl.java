package com.capg.gear.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capg.gear.model.GearForm;

@Repository

@Transactional
public class GearDaoImpl implements IGearDao{
	@PersistenceContext
	EntityManager em;

	@Override
	public GearForm findqueryID(Integer queryID) {
		return em.find(GearForm.class, queryID);
	}

	

	@Override
	public boolean textarea(Integer queryID, String textarea) {
		
		GearForm t=em.find(GearForm.class, queryID);
		t.setSolutions(textarea);
		System.out.println(textarea);
		em.merge(t);
		
		
		return true;
	}

}
