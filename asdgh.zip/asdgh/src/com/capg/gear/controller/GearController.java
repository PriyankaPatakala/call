package com.capg.gear.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capg.gear.model.GearForm;
import com.capg.gear.service.IGearService;

@Controller
public class GearController {
	@Autowired
	IGearService service;

	/*@RequestMapping("/home")
	public String home(Model model) {
		String view = "technicalform";
		ArrayList<HotelDetails> list = service.getAllHotels();
		model.addAttribute("hotellist", list);
		return view;
	}*/

	@RequestMapping("/firstpage")
	public ModelAndView answer(@RequestParam("queryID") Integer queryID){
		System.out.println(queryID);
		GearForm query= service.findqueryID(queryID);
		System.out.println(query);
		return new ModelAndView("answersheet","all",query);
	}
	/*@RequestMapping("/feed")
	public String feed(@PathVariable("all"),Model model){
		String view = "";
		TestBean query= (TestBean)service.findqueryID(queryID);
		model.addAttribute("queryID", query);
		view = "answerfrom";
		return view;*/
	@RequestMapping("/next")
	public ModelAndView success(@RequestParam("queryid") Integer queryID,@RequestParam("textarea") String textarea){
		System.out.println( queryID);
		System.out.println(textarea);
		boolean id=service.textarea(queryID,textarea);
		if(id) {
		return new ModelAndView("success","queryId", queryID);}
		else{return new ModelAndView("error","string","invalid");} 
	}
	}



