package com.capg.gear.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component
@Entity(name="GearTech") //query
@Transactional
public class GearForm {
	
	@Id
	private Integer queryID;
	
	String technology;
	String questionRaisedBy;
	String question;
	String solutions;
	String answeredBy;
	public Integer getQueryID() {
		return queryID;
	}
	public void setQueryID(Integer queryID) {
		this.queryID = queryID;
	}
	public String getTechnology() {
		return technology;
	}
	public void setTechnology(String technology) {
		this.technology = technology;
	}
	
	public String getQuestionRaisedBy() {
		return questionRaisedBy;
	}
	public void setQuestionRaisedBy(String questionRaisedBy) {
		this.questionRaisedBy = questionRaisedBy;
	}
	public String getAnsweredBy() {
		return answeredBy;
	}
	public void setAnsweredBy(String answeredBy) {
		this.answeredBy = answeredBy;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getSolutions() {
		return solutions;
	}
	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}
	
	

}
