package com.capgemini.trg.ui;

import java.util.Enumeration;
import java.util.Locale;
import java.util.ResourceBundle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class RBTester {

	public static void main(String[] args)
	{
		ApplicationContext context = new ClassPathXmlApplicationContext("sprin1.xml");
		System.out.println("-------------");
		Locale currentLocale = Locale.getDefault();
		System.out.println(currentLocale.getLanguage());
		System.out.println(currentLocale.getCountry());
		System.out.println("-------------");
		
		String message = context.getMessage("greetings",null,null);
		System.out.println(message);
		System.out.println("-------------");
	 message = context.getMessage("greetings",null,Locale.FRANCE);
	 System.out.println(message);
	 System.out.println("-------------");
	 //same as the above syntax22 23 24
		Locale frenchLocale = new Locale("fr","FR");
		message = context.getMessage("greetings", null,frenchLocale);
		System.out.println(message);
		
		//reading the labels and values of particular file
		ResourceBundle bundle = ResourceBundle.getBundle("messages_fr_FR",frenchLocale);
		Enumeration enumeration = bundle.getKeys();
		while(enumeration.hasMoreElements())
		{
		String Key = (String) enumeration.nextElement();
		System.out.println(Key+"=" +bundle.getObject(Key));
		}
		
		
		
		
		
		
	}

}
