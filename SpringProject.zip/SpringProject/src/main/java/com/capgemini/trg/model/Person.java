package com.capgemini.trg.model;

public class Person 
{
    private Long adharNumber;
    private String name;
    private Address residentialAddress;
    private Address permanentAddress;
    
    public Person()
    {
    	
    }

	public Long getAdharNumber() {
		return adharNumber;
	}

	public void setAdharNumber(Long adharNumber) {
		this.adharNumber = adharNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Address getResidentialAddress() {
		return residentialAddress;
	}

	public void setResidentialAddress(Address residentialAddress) {
		this.residentialAddress = residentialAddress;
	}

	public Address getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(Address permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public Person(Long adharNumber, String name, Address residentialAddress,
			Address permanentAddress) {
		super();
		this.adharNumber = adharNumber;
		this.name = name;
		this.residentialAddress = residentialAddress;
		this.permanentAddress = permanentAddress;
	}
	
	public void initialize()
	{
		System.out.println("initialisation before bean instantiation");
	}
	
	public void cleanUp()
	{
		System.out.println("initialisation before bean destruction");
	}
	
	
	
	
}
