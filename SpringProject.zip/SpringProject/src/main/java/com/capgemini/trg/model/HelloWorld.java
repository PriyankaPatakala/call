package com.capgemini.trg.model;

public class HelloWorld 
{
    private String message;
    public HelloWorld()
    {
    	this.message = "Good morning";
    }
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public void setup()
	{
		System.out.println("setupmethod");
	}
    public void destroy()
    {
    	System.out.println("destroymethod");
    }
}
