function chkEmpty(){
	
	if (document.frm1.userName.value == "") {alert("Please fill the First Name");}
	else if(document.frm1.city.value=="") {alert("please fill the city");}
	else if (document.frm1.password.value == "") {alert("Please fill the password");}
	else if (document.frm1.gender.value == "") {alert("Please select gender");}
	else if (document.frm1.lang.value == "") {alert("Please select languages");}
	else if (document.frm1.hidden.value == "") {alert("Please fill hidden box");}
	else if (document.frm1.number.value == "") {alert("Please fill the number");}
	else if (document.frm1.email.value == "") {alert("Please fill the email box");}
	else if (document.frm1.mobile.value == "") {alert("Please fill the mobile number");}

	
	else {
		alert(" completed Successfully.");

			}
		}