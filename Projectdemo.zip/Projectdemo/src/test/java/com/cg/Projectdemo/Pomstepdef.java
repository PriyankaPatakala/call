package com.cg.Projectdemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class Pomstepdef {

	private PageFactoryregistration fact;
	private WebDriver driver;
	
	@Given("^check user name$")
	public void check_user_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^enter empty value in user name text box$")
	public void enter_empty_value_in_user_name_text_box() throws Throwable {
		fact.setuserName("");
		fact.setstore();

	}

	@Then("^print error message for name field$")
	public void print_error_message_for_name_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the city name$")
	public void check_the_city_name() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user enters empty value in the city name$")
	public void the_user_enters_empty_value_in_the_city_name() throws Throwable {
		fact.setuserName("priyanka");
		fact.setcity("");
		fact.setstore();
	
	}

	@Then("^print error message for city field$")
	public void print_error_message_for_city_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check user password$")
	public void check_user_password() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^enter empty value in password text box$")
	public void enter_empty_value_in_password_text_box() throws Throwable {
	   fact.setuserName("priyanka");
	   fact.setcity("Hyderabad");
	   fact.setpassword("");
	   fact.setstore();
	}

	@Then("^print error message for password field$")
	public void print_error_message_for_password_field() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the gender$")
	public void check_the_gender() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user doesnt enter the gender$")
	public void the_user_doesnt_enter_the_gender() throws Throwable {
		 fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.setstore();
	}

	@Then("^print select any one option$")
	public void print_select_any_one_option() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the languages$")
	public void check_the_languages() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user doesnt select atleast one option$")
	public void the_user_doesnt_select_atleast_one_option() throws Throwable {
		fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.gender.click();
		   fact.setstore();
	}

	@Then("^print error message for languages known$")
	public void print_error_message_for_languages_known() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the hidden$")
	public void check_the_hidden() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user lefts the hidden box empty$")
	public void the_user_lefts_the_hidden_box_empty() throws Throwable {
		fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.gender.click();
		   
		   fact.lang.click();
		   fact.setHidden("");
		   fact.setstore();
	}

	@Then("^print error message for hidden$")
	public void print_error_message_for_hidden() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}
	@Given("^check the My number$")
	public void check_the_My_number() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user doesnt enter the number$")
	public void the_user_doesnt_enter_the_number() throws Throwable {
		fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.gender.click();
		   fact.lang.click();
		   fact.setHidden("my employee name ");
		    //fact.setEmail("hgsduy@gmail.com");
		   fact.setNumber("");
		   fact.setstore();
	}

	@Then("^print error message for My number$")
	public void print_error_message_for_My_number() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the email$")
	public void check_the_country() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user doesnt enter the email$")
	public void the_user_doesnt_select_the_country() throws Throwable {
		fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.gender.click();
		   fact.lang.click();
		   fact.setHidden("my emp id is");
		   fact.setNumber("20");
		   fact.setEmail("");
		   fact.setstore();
	}

	@Then("^print error message for email$")
	public void print_error_message_for_country() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();     
	}

	

	@Given("^check the mobile number$")
	public void check_the_mobile_number() throws Throwable {
		System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");

	}

	@When("^the user doesnt enter the mobile number$")
	public void the_user_doesnt_enter_the_mobile_number() throws Throwable {
		fact.setuserName("priyanka");
		   fact.setcity("Hyderabad");
		   fact.setpassword("gdg12345");
		   fact.gender.click();
		   fact.lang.click();
		   fact.setHidden("my employee name ");
		   fact.setNumber("20");
		   fact.setEmail("hgsduy@gmail.com");
		   fact.setMobile("");
		   fact.setstore();
	}

	@Then("^print error message for mobile number$")
	public void print_error_message_for_mobile_number() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
		System.out.println("alert :: "+alertMessage);
		Thread.sleep(2000);
		driver.close();  
	}

	@Given("^check the alternate number$")
	public void check_the_alternate_number() throws Throwable {
		/*System.setProperty("webdriver.chrome.driver", "D:\\Core Java 8\\all\\software\\chromedriver.exe");
		driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		fact = new PageFactoryregistration(driver);
		driver.get("file:///C:/springprojects/Projectdemo/src/test/java/pom.html");
*/
	}

	@When("^the user doesnt enter the alternate number$")
	public void the_user_doesnt_enter_the_alternate_number() throws Throwable {
	    
	}

	@Then("^print error message for alternate number$")
	public void print_error_message_for_alternate_number() throws Throwable {
	  
	}


	
	
	
	
	
	
	
}
