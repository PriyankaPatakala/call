package com.cg.Projectdemo;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;



public class PageFactoryregistration {
	

	WebDriver wd;

	public PageFactoryregistration(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}
public  PageFactoryregistration()
{
	
}
	@FindBy(xpath = "/html/body/form/input[2]")
	@CacheLookup
	WebElement userName;

	@FindBy(xpath = "/html/body/form/input[3]")
	@CacheLookup
	WebElement city;

	@FindBy(xpath = "/html/body/form/input[4]")
	@CacheLookup
	WebElement password;
	
	@FindBy(xpath = "/html/body/form/input[6]")
	@CacheLookup
	WebElement gender;

	@FindBy(xpath = "/html/body/form/input[7]")
	@CacheLookup
	WebElement lang;
	

	@FindBy(xpath = "/html/body/form/textarea")
	@CacheLookup
	WebElement hidden;
	

	@FindBy(name = "coun")
	@CacheLookup
	WebElement country;
	
	@FindBy(xpath ="/html/body/form/input[11]" )
	@CacheLookup
	WebElement number;

	@FindBy(xpath = "/html/body/form/input[12]")
	@CacheLookup
	WebElement email;

	
	@FindBy(xpath = "/html/body/form/input[13]")
	@CacheLookup
	WebElement mobile;

	@FindBy(name = "altnum")
	@CacheLookup
	WebElement alternatenumber;

	@FindBy(xpath="/html/body/form/input[15]")
	@CacheLookup
	WebElement store;
	
	public WebElement getstore() {
		return store;
	}

	public void setstore() {
		store.click();
	}
	public WebElement getuserName() {
		return userName;
	}

	public void setuserName(String userName) {
		this.userName.sendKeys(userName);
	}
	
	public WebElement getcity() {
		return city;
	}

	public void setcity(String city) {
	this.city.sendKeys(city);
	}
	
	public WebElement getpassword() {
		return password;
	}

	public void setpassword(String password) {
		this.password.sendKeys(password);
	}
	public WebElement getgender() {
		return gender;
	}
	
	public void setgender() {
		gender.click();
	}
	
	public WebElement getlang() {
		return lang;
	}
	public void setlang() {
		lang.click();
	}
	public WebElement getHidden() {
		return hidden;
	}
	public void setHidden(String hidden) {
		this.hidden.sendKeys(hidden);
	}
	public WebElement getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number.sendKeys(number);
	}
	public WebElement getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public WebElement getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile.sendKeys( mobile); 
	}
	
	
	
	
	
	
	
	
	


}
