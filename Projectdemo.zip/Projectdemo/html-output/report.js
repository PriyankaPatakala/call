$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("com/cg/Projectdemo/pom.feature");
formatter.feature({
  "line": 1,
  "name": "Login Page",
  "description": "",
  "id": "login-page",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Test name",
  "description": "",
  "id": "login-page;test-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "check user name",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "enter empty value in user name text box",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "print error message for name field",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_user_name()"
});
formatter.result({
  "duration": 4475711544,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.enter_empty_value_in_user_name_text_box()"
});
formatter.result({
  "duration": 167201241,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_name_field()"
});
formatter.result({
  "duration": 4170150257,
  "status": "passed"
});
formatter.scenario({
  "line": 9,
  "name": "Test city",
  "description": "",
  "id": "login-page;test-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 10,
  "name": "check the city name",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "the user enters empty value in the city name",
  "keyword": "When "
});
formatter.step({
  "line": 12,
  "name": "print error message for city field",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_city_name()"
});
formatter.result({
  "duration": 4389618269,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_enters_empty_value_in_the_city_name()"
});
formatter.result({
  "duration": 244570535,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_city_field()"
});
formatter.result({
  "duration": 6128288107,
  "status": "passed"
});
formatter.scenario({
  "line": 14,
  "name": "Test password",
  "description": "",
  "id": "login-page;test-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 16,
  "name": "check user password",
  "keyword": "Given "
});
formatter.step({
  "line": 17,
  "name": "enter empty value in password text box",
  "keyword": "When "
});
formatter.step({
  "line": 18,
  "name": "print error message for password field",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_user_password()"
});
formatter.result({
  "duration": 2940231680,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.enter_empty_value_in_password_text_box()"
});
formatter.result({
  "duration": 287630914,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_password_field()"
});
formatter.result({
  "duration": 4492127003,
  "status": "passed"
});
formatter.scenario({
  "line": 20,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 22,
  "name": "check the gender",
  "keyword": "Given "
});
formatter.step({
  "line": 23,
  "name": "the user doesnt enter the gender",
  "keyword": "When "
});
formatter.step({
  "line": 24,
  "name": "print select any one option",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_gender()"
});
formatter.result({
  "duration": 2888735287,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_enter_the_gender()"
});
formatter.result({
  "duration": 277943344,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_select_any_one_option()"
});
formatter.result({
  "duration": 4133081846,
  "status": "passed"
});
formatter.scenario({
  "line": 26,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "check the languages",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "the user doesnt select atleast one option",
  "keyword": "When "
});
formatter.step({
  "line": 30,
  "name": "print error message for languages known",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_languages()"
});
formatter.result({
  "duration": 3022117408,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_select_atleast_one_option()"
});
formatter.result({
  "duration": 343415254,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_languages_known()"
});
formatter.result({
  "duration": 6396906919,
  "status": "passed"
});
formatter.scenario({
  "line": 32,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "check the hidden",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "the user lefts the hidden box empty",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "print error message for hidden",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_hidden()"
});
formatter.result({
  "duration": 2842836239,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_lefts_the_hidden_box_empty()"
});
formatter.result({
  "duration": 472990606,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_hidden()"
});
formatter.result({
  "duration": 6084230912,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "check the email",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "the user doesnt enter the email",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "print error message for email",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_country()"
});
formatter.result({
  "duration": 2738076671,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_select_the_country()"
});
formatter.result({
  "duration": 624632091,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_country()"
});
formatter.result({
  "duration": 4283174779,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 46,
  "name": "check the country",
  "keyword": "Given "
});
formatter.step({
  "line": 47,
  "name": "the user doesnt select the country",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "print error message for country",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 50,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 52,
  "name": "check the My number",
  "keyword": "Given "
});
formatter.step({
  "line": 53,
  "name": "the user doesnt enter the number",
  "keyword": "When "
});
formatter.step({
  "line": 54,
  "name": "print error message for My number",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_My_number()"
});
formatter.result({
  "duration": 2765511250,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_enter_the_number()"
});
formatter.result({
  "duration": 552106172,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_My_number()"
});
formatter.result({
  "duration": 6071122172,
  "status": "passed"
});
formatter.scenario({
  "line": 56,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 58,
  "name": "check the mobile number",
  "keyword": "Given "
});
formatter.step({
  "line": 59,
  "name": "the user doesnt enter the mobile number",
  "keyword": "When "
});
formatter.step({
  "line": 60,
  "name": "print error message for mobile number",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_mobile_number()"
});
formatter.result({
  "duration": 2803766403,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_enter_the_mobile_number()"
});
formatter.result({
  "duration": 728232400,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_mobile_number()"
});
formatter.result({
  "duration": 6120294303,
  "status": "passed"
});
formatter.scenario({
  "line": 62,
  "name": "",
  "description": "",
  "id": "login-page;",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 64,
  "name": "check the alternate number",
  "keyword": "Given "
});
formatter.step({
  "line": 65,
  "name": "the user doesnt enter the alternate number",
  "keyword": "When "
});
formatter.step({
  "line": 66,
  "name": "print error message for alternate number",
  "keyword": "Then "
});
formatter.match({
  "location": "Pomstepdef.check_the_alternate_number()"
});
formatter.result({
  "duration": 27895,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.the_user_doesnt_enter_the_alternate_number()"
});
formatter.result({
  "duration": 18460,
  "status": "passed"
});
formatter.match({
  "location": "Pomstepdef.print_error_message_for_alternate_number()"
});
formatter.result({
  "duration": 14768,
  "status": "passed"
});
});