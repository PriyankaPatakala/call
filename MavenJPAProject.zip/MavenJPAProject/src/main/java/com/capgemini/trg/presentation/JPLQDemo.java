package com.capgemini.trg.presentation;

import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.capgemini.jpa.entity.Employee;
import com.capgemini.jpa.utility.JPAUtil;

public class JPLQDemo {

	public static void main(String[] args) 
	
	{
		EntityManager entityManager = JPAUtil.getEntityManager();
		
		//named parameters//
		/*String jql1 = "select e from Employee e";
		 String jql2="Select e from Employee e where e.empid='2'";
		TypedQuery<Employee> typedQuery1 = entityManager.createQuery(jql1 , Employee.class);
		TypedQuery<Employee> typedQuery2 = entityManager.createQuery(jql2,Employee.class);
		 Employee employee=typedQuery2.getSingleResult();
	        System.out.println(employee);
		List<Employee> employeeList = typedQuery1.getResultList();
		showEmployees(employeeList);*/
		/*String jql2 = "select e from Employee e where e.job = :pjob AND e.salary > :psalary ";//pjob are named parameters
		TypedQuery<Employee> typedQuery = entityManager
				.createQuery(jql2,Employee.class)
				.setParameter("pjob","Manager")
		        .setParameter("psalary",10000.00);
		List<Employee> employeeList = typedQuery.getResultList();
		showEmployees(employeeList);
		
		Query query1 = entityManager.createNamedQuery("q1");
		List <Employee> employeeList = query1.getResultList();
		showEmployees(employeeList);
		
		
		
		//ordinal parameters//
		String jql2 = "select e from Employee e where e.job = ?1 AND e.deptno =?2 ";//pjob are named parameters
		TypedQuery<Employee> typedQuery = entityManager
				.createQuery(jql2,Employee.class)
				.setParameter(1,"Manager")
		        .setParameter(2,10);
		List<Employee> employeeList = typedQuery.getResultList();
		showEmployees(employeeList);*/
	
		Query query = entityManager.createNativeQuery("select * from employee where job = ?",Employee.class);
	 query.setParameter(1,"Developer");
	 List<Employee> employeeList = query.getResultList();
	 showEmployees(employeeList);

	}
		
	private static void showEmployees(List<Employee> employeeList)
	{
		Iterator<Employee> iterator = employeeList.iterator();
		while(iterator.hasNext())
		{
			System.out.println(iterator.next());
		}

		
		
		
		
		
		 
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
