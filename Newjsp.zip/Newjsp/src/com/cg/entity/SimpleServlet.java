package com.cg.entity;

import java.io.IOException;


import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SimpleServlet  extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>simple</h1>");
		ServletConfig config = getServletConfig();
		String name=config.getInitParameter("myname");
		String city=config.getInitParameter("city");
		 out.println("hello"+name+" you are from"+city);
		 
		 ServletContext context=getServletContext();
		 String p1=context.getInitParameter("param1");
		 String p2=context.getInitParameter("param2");
		 String p3=context.getInitParameter("param3");
		 String p4=context.getInitParameter("param4");
		 
		 
		 out.println("<hr>");
		 out.println("Parm 1 ="+p1+"<br>");
		 out.println("Parm 2 ="+p2+"<br>");
		 out.println("Parm 3 ="+p3+"<br>");
		 out.println("Parm 4 ="+p4+"<br>");
	
}

}