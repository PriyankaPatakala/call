package com.cg.entity;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(urlPatterns="/LoginServlet",initParams={@WebInitParam(name="user",value="aarush"),
		@WebInitParam(name="password",value="aaru")})





public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public LoginServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		String userName=request.getParameter("username");
		String pwd=request.getParameter("pwd");
		String u=getServletConfig().getInitParameter("user");
		String p=getServletConfig().getInitParameter("password");
		if(userName.equals(u) && pwd.equals(p))
		{
			out.println("<h1 Welcome "+userName+"</h1>");
			out.println("<a href='GreetServlet?user="+userName+"'><button>Greet</button></a>");
			
			
			/*out.println("<form method='post' action='GreetServlet'>");
			out.println("<input type='hidden' value='"+userName+"' name='user'/>");
			out.println("<input type='submit' value='Greet'/>");
			out.println("</form>");*/
			
			
			//response.sendRedirect("success.html");1 type
			
		/*	RequestDispatcher rd = request.getRequestDispatcher("success.html");//3 type
			rd.forward(request, response);
			*/
			/*ServletContext context = getServletContext();/2 type
			RequestDispatcher rd = request.getRequestDispatcher("/success.html");
			rd.forward(request, response);
			*/
			
			
		}
		else
		{
			//response.sendRedirect("eror.html");
			RequestDispatcher rd = request.getRequestDispatcher("error.html");
			rd.forward(request, response);
			
		}
	}

}
