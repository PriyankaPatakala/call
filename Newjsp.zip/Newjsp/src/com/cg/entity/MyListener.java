package com.cg.entity;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;


@WebListener
public class MyListener implements ServletContextListener{

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		
	
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		
		ServletContext	ctx = sce.getServletContext();
		ctx.setInitParameter("param3", "delhi");
		ctx.setInitParameter("param4", "mumbai");
	}

}
