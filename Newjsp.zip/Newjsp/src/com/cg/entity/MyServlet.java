package com.cg.entity;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//more url patterns (urlpaterns={"/MyServlet","/Hello"})


//@WebServlet("/MyServlet")

@WebServlet(urlPatterns={"/MyServlet","/Hello"},
initParams={@WebInitParam(name="user",value="priya"),
		    @WebInitParam(name="company",value="capg")
		},loadOnStartup=1)

public class MyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		ServletConfig config = getServletConfig();
		String name = config.getInitParameter("user");
		String company = config.getInitParameter("company");
		 out.println("hello"+name+" you work in "+company);
	
		 ServletContext context = getServletContext();
		 String p1=context.getInitParameter("param1");
		 String p2=context.getInitParameter("param2");
		 String p3=context.getInitParameter("param3");
		 String p4=context.getInitParameter("param4");
		 
		 
		 out.println("<hr>");
		 out.println("Parm 1 ="+p1+"<br>");
		 out.println("Parm 2 ="+p2+"<br>");
		 out.println("Parm 3 ="+p3+"<br>");
		 out.println("Parm 4 ="+p4+"<br>");
	}

}
