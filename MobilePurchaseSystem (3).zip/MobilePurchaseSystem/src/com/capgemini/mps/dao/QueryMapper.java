package com.capgemini.mps.dao;

public interface QueryMapper {
	public static final String INSERT_MOBILE = "INSERT INTO mobile (name,price,quantity)values(?,?,?)";
	public static final String DELETE_MOBILE = "DELETE FROM mobile WHERE mobile_id=?";
	public static final String SELECT_MOBILE = "SELECT *FROM mobile WHERE mobile_id=?";
	public static final String SELECT_ALL_MOBILE = "SELECT * FROM mobile"	;	
	public static final String UPDATE_MOBILE = "UPDATE mobile SET price=? where mobile_id=?";
    public static final String GET_MOBILE_DETAILS="{call get_mobile_details(?,?,?,?)}";
    public static final String GET_MOBILE_PRICE="{?=get_mobile_price(?)}";
	public static final String SELECT_ALL_MOB = "SELECT * ";
}
