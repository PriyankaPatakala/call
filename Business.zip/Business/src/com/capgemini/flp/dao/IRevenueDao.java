package com.capgemini.flp.dao;

import java.util.List;

import com.capgemini.flp.entity.Revenue;
import com.capgemini.flp.exception.RevenueException;

public interface IRevenueDao {

	Revenue findProductSold(String merchant_email_Id);

	Double findTotalRevenue();

	

}
