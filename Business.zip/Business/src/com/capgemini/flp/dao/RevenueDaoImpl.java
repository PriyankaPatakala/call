package com.capgemini.flp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.flp.entity.Revenue;


@Repository
@Transactional

public class RevenueDaoImpl implements IRevenueDao{
	@PersistenceContext
	EntityManager em;
	Revenue rev = new Revenue();
	public Revenue findProductSold(String merchant_email_Id) {
		
		 TypedQuery<Revenue> query=em.createQuery("select rev from Revenue rev where rev.merchant_email_Id=?",Revenue.class);
			query.setParameter(1,merchant_email_Id);
			 rev = query.getSingleResult();
			return rev;	
			
			/*double totalRevenue=rev.getNumberOfProductSold()*rev.getSellingCost();	 
              return rev;*/
              
		 
				/*if(merchant.getProduct_Promo().equalsIgnoreCase(promo))//get the promo code from the user
						{

						 d=((5*merchant.getProduct_Price())/100);
						 
						}
						else
						{
						d = 0;
						}
						merchant.setProduct_Price(merchant.getProduct_Price()-d);
						merchant.setProduct_Discount(d);
						em.persist(merchant);
						System.out.println(merchant);
				    
						
						return merchant;
					
				} */
		
	}
	@Override
	public Double findTotalRevenue() {
		double totalRevenue=rev.getNumberOfProductSold()*rev.getSellingCost();	
		em.merge(totalRevenue);
      return totalRevenue;
	}
	
	
}

	


	