package com.cg.trg.service;

import java.util.List;

import com.cg.trg.entity.Session12;

public interface ITrainingService {

	public List<Session12> getAllDetails();

}
