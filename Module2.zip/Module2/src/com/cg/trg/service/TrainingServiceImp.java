package com.cg.trg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trg.dao.ITrainingdao;
import com.cg.trg.entity.Session12;

@Service("trainingservice")      // same as obj created in controller class
@Transactional

public class TrainingServiceImp implements ITrainingService {

	@Autowired
	ITrainingdao trainingdao;                     //creating and sending to dao

	@Override
	public List<Session12> getAllDetails() {
		// TODO Auto-generated method stub
		return trainingdao.getAllDetails();           //returning the value of list
	}

}
