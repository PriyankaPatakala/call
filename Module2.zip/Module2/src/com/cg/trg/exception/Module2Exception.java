package com.cg.trg.exception;

public class Module2Exception extends Exception {
	
private static final long serialVersionUID = 1L;
	
	public String msg;
	public Module2Exception(String msg) {
		this.msg = msg;
	}
	
	public String getMessage() {
		return msg;
	}
}


