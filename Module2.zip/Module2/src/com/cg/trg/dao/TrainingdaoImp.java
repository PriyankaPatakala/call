package com.cg.trg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.trg.entity.Session12;



@Repository("trainingdao")                                     //
public class TrainingdaoImp implements ITrainingdao {          //


	@PersistenceContext                                //
	EntityManager em;                                    //
	
	@Override
	public List<Session12> getAllDetails() {
		// TODO Auto-generated method stub
		
		Query queryGet=em.createQuery("FROM Session12");
		List<Session12> myAll=queryGet.getResultList();
		return myAll;
	}

}
