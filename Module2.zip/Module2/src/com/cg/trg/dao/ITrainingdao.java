package com.cg.trg.dao;

import java.util.List;

import com.cg.trg.entity.Session12;

public interface ITrainingdao {

	public List<Session12> getAllDetails();
}
