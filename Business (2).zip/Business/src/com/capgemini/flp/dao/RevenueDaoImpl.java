package com.capgemini.flp.dao;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capgemini.flp.entity.Revenue;


@Repository
@Transactional

public class RevenueDaoImpl implements IRevenueDao{
	@PersistenceContext
	EntityManager em;
	Revenue rev = new Revenue();
	
	public Revenue findProductSold(String merchant_email_Id) {
		/*Revenue r1=em.find(Revenue.class,merchant_email_Id);
		if(r1!=null){
			double revenue=r1.getNumberOfProductSold() * r1.getSellingCost();	
			em.merge(revenue);
		}*/
		 TypedQuery<Revenue> query=em.createQuery("select rev from Revenue rev where rev.merchant_email_Id=?",Revenue.class);
			query.setParameter(1,merchant_email_Id);
			
			 rev = query.getSingleResult();
			 double rev1= (double)rev.getNumberOfProductSold() * rev.getSellingCost();
			rev.setRevenue(rev1);
			em.persist(rev);
			
			
			
			/* em.merge(rev1);*/
			return rev;	
				
	/*}
	@Override
	public Double findTotalRevenue() {
		double totalRevenue=rev.getNumberOfProductSold()*rev.getSellingCost();	
		em.merge(totalRevenue);
      return totalRevenue;
	}
	*/
	
}

	

}
	