package com.capg.miniproject.exception;

public class BankCustomerexception extends Exception
{
	
	public BankCustomerexception(String a)
	{
		super(a);
	}

}
