
package com.capg.miniproject.dao;

import com.capg.miniproject.entity.BankCustomer;
import com.capg.miniproject.exception.BankCustomerexception;

public interface IBankCustomerdao  
{
    public boolean createAccount(BankCustomer bean) throws BankCustomerexception;

    public double showBalance(BankCustomer m) throws BankCustomerexception;
    
    public boolean valid(long id) ;
    
    //public boolean valid(int pin) ;
    
    public BankCustomer displayBankCustomer(long id);
    
    public double deposit(long accno,double amount) throws BankCustomerexception;
    
    public double withDraw(BankCustomer d,double amount) throws BankCustomerexception;
    
    public double fundTransfer(BankCustomer b,BankCustomer c,double amount) throws BankCustomerexception;
    
    public boolean printTransactions(long id7);

} 
