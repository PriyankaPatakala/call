
package com.capg.miniproject.dao;

import java.util.HashMap;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capg.miniproject.entity.BankCustomer;
import com.capg.miniproject.exception.BankCustomerexception;
import com.capg.miniproject.utility.JPAUtil;




public class BankCustomerdaoimp implements IBankCustomerdao{
	HashMap<Long,BankCustomer> acctList = new HashMap<Long,BankCustomer>();
	private EntityManager entitymanager = null;
	BankCustomer bean=new BankCustomer();
	double temp =0.0;

	public boolean createAccount(BankCustomer bean) throws BankCustomerexception {
		EntityManager entitymanager = null;

		try{
			entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
			entitymanager.getTransaction().begin();
			bean.setAccno(0);
			entitymanager.persist(bean);
			entitymanager.getTransaction().commit();
			return entitymanager.contains(bean); }
		catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankCustomerexception(e.getMessage()); }
		finally {
			entitymanager.close();}
	}

	public BankCustomer displayBankCustomer(long id3) {
		entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();       
		BankCustomer bean = entitymanager.find(BankCustomer.class, id3) ;
		entitymanager.close();
		return bean;
	}

	public boolean valid(long id3){ 
      entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
      entitymanager.getTransaction().begin();
       BankCustomer bean = entitymanager.find(BankCustomer.class, id3) ;

       if(bean == null)
       {
    	   return false;
       }
       return true;
    }
	 


	public double showBalance(BankCustomer m) throws BankCustomerexception {

		try {
			entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
			BankCustomer bean = entitymanager.find(BankCustomer.class, m) ;
			m.getBalance(); }
		catch(PersistenceException e) {
			e.printStackTrace();
			throw new BankCustomerexception(e.getMessage()); }
		finally {
			entitymanager.close(); }
		return m.getBalance();}


	public double deposit(long accno,double amount) throws BankCustomerexception {

		
		try		{
			entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
			entitymanager.getTransaction().begin();
			BankCustomer bean = entitymanager.find(BankCustomer.class, accno) ;
			temp = bean.getBalance();
			//currbal=(currbal+bean.getBalance()+amount);
			temp = temp + amount;
			System.out.println(temp);
			bean.setBalance(temp);
			entitymanager.merge(bean);
			
			//double currbal = bean.getBalance();
			return bean.getBalance(); 
			
			}
		catch(PersistenceException e)	{
			System.out.println(e.getMessage());
			throw new BankCustomerexception(e.getMessage());}
		finally	{
			entitymanager.getTransaction().commit();
			entitymanager.close();}
		//return currbal;
	}

	public double withDraw(BankCustomer d,double amount2) throws BankCustomerexception 	{ 
		double currbal=0;
		try		{
			entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
			BankCustomer bean = entitymanager.find(BankCustomer.class, d) ;
			if(d.getBalance()-amount2>500) 			{
				currbal=(currbal+d.getBalance()-amount2);
				d.setBalance(currbal);
			}			else			{
				System.out.println("insufficient amount");
			}
			entitymanager.getTransaction().begin();
			entitymanager.merge(bean);
			entitymanager.getTransaction().commit();
			currbal = bean.getBalance();
			return currbal;
		}
		catch(PersistenceException e)		{
			e.printStackTrace();
			throw new BankCustomerexception(e.getMessage());
		}
		finally		{
			entitymanager.close();
		}




	}



	@Override
	public double fundTransfer(BankCustomer b,BankCustomer c, double amount3) throws BankCustomerexception
	{
		try
		{
			entitymanager =Persistence.createEntityManagerFactory("miniproject").createEntityManager();
			BankCustomer bean = entitymanager.find(BankCustomer.class, b) ;     
			double currbal1=0;
			double currbal2=0;
			if((amount3<b.getBalance())&&(b.getBalance()-amount3>500))
			{
				currbal1=(currbal1+b.getBalance()-amount3);
				b.setBalance(currbal1);
				currbal2=(currbal2+c.getBalance()+amount3);
				c.setBalance(currbal2);
			}
			else
			{
				System.out.println("withdraw not possible");
			}
			entitymanager.getTransaction().begin();
			entitymanager.merge(bean);
			entitymanager.getTransaction().commit();
			currbal2 = bean.getBalance();
			return currbal2;      
		}
		catch(PersistenceException e)

		{
			e.printStackTrace();
			throw new BankCustomerexception(e.getMessage());
		}
		finally
		{
			entitymanager.close();
		}

	}





	public boolean printTransactions(long id7){
		return false;

	}





}

