package com.capg.miniproject.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capg.miniproject.dao.BankCustomerdaoimp;
import com.capg.miniproject.entity.BankCustomer;
import com.capg.miniproject.exception.BankCustomerexception;

public class  IBankCustomerserviceimp implements IBankCustomerservice{
	BankCustomerdaoimp dao= new BankCustomerdaoimp();
    
    public boolean createAccount(BankCustomer bean) throws BankCustomerexception
    {
        return dao.createAccount(bean);
        
    }
    public BankCustomer displayBankCustomer(long id3) {
        
        return dao.displayBankCustomer(id3);
    }

    public double showBalance(BankCustomer m) throws BankCustomerexception
    {
        return dao.showBalance(m);
        
    }
    public boolean valid(long id)
    {
        return dao.valid(id);
    }
   /* public boolean valid(int pin)
    {
        return dao.valid(pin);
    }*/
    
    public double deposit(long accno,double amount) throws BankCustomerexception
    {
        return dao.deposit(accno,amount);
    }
    
    public double withDraw(BankCustomer d,double amount) throws BankCustomerexception
    {
        return dao.withDraw(d,amount);
    }
    
    public double fundTransfer(BankCustomer b,BankCustomer c,double amount) throws BankCustomerexception{
        return dao.fundTransfer(b,c,amount);
    }
    
    public boolean printTransactions(long id7){
        return dao.printTransactions(id7);
        
    }
        
    public boolean validateAccno(BankCustomer bean,long id)
        {boolean flag=false;
        if((bean.getAccno()==id)){
                flag=true;
            }
            return flag;
                    }
    public boolean validatepin(BankCustomer bean,int pin)
    {boolean flag=false;
    if((bean.getPin()==pin)){
            flag=true;
        }
        return flag;
                }
    public boolean validateAccnoPinno(BankCustomer m,long id,int pin)
    {boolean flag=false;
    if((m.getAccno()==id)&&(m.getPin()==pin)){
            flag=true;
        }
        return flag;
                }
    public boolean validateAccname(String accName){
        boolean flag=true;
        Pattern pattern=Pattern.compile("[A-za-z]*");
        Matcher m = pattern.matcher(accName);
        if((m.matches()) && (accName.length()>2))
        {
            flag=false;
        }
        return flag;
    }
public boolean validateAddress(StringBuffer addr){
    boolean flag=true;
    Pattern pattern=Pattern.compile("[A-Z]{1}[a-z]*");
    Matcher m = pattern.matcher(addr);
    if(m.matches())
    {
     flag=false;
    }
    return flag;
}
    public boolean validatemobNum(StringBuffer mobNum){
        boolean flag=true;
        Pattern pattern=Pattern.compile("[7-9][0-9]{9}");
        Matcher m = pattern.matcher(mobNum);
        if(m.matches())
        {
         flag=false;
        }
        return flag;
    }
    public boolean validateidProof(StringBuffer idProofNo){
        boolean flag=true;
        Pattern pattern=Pattern.compile("[0-9][0-9]{9}");
        Matcher m = pattern.matcher(idProofNo);
        if(m.matches())
        {
         flag=false;
        }
        return flag;
    }
    public boolean validateAge(int age){
        boolean flag=true;
        if(age>18)
        {
            flag=false;
        }
        return flag;
    }
    
    public boolean validateEmailId(String emailid){
        boolean flag=true;
        Pattern pattern=Pattern.compile("[a-zA-Z0-9.]*@[a-zA-Z0-9]+([.][a-zA-z]+)");
        Matcher m = pattern.matcher(emailid);
        if(m.matches())
        {
         flag=false;
        }
        return flag;
    }
    
    }
